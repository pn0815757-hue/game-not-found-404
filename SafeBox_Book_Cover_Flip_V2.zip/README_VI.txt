SAFE BOX - BOOK COVER FLIP V2

CHỈ THAY 2 FILE:
Assets/Scripts/SafeBoxBookFlip.cs
Assets/Editor/SafeBoxBookFlipSetup.cs

1. Thoat Play Mode.
2. Copy Assets/ trong ZIP vao thu muc goc P1/ (ghi de 2 file C# tren, KHONG xoa cac thu muc khac).
3. Mo Unity: Assets/Scenes/SafeBoxPuzzle.unity
4. Chon Tools > Safe Box > Install Book Opening Animation
5. Ctrl+S, Play va test: 0904 > click so > click bia mo > click lan nua de dong.

MOI:
- Anh so mo kich thuoc khung gap 2 so dong (openedSizeMultiplier = 2).
- Hieu ung bia so quay quanh gay so phia trai (xoay truc Y, khong ep xep ca cuon so).
- Frame o cung tam, preserveAspect=true.

LUU Y: Anh so mo 2x co the vuot ra ngoai Game View neu cua so Game qua thap.
Vi tri noi dung co the chenh do padding trong file PNG goc; nen crop/can giua 2 sprite neu can.
Chua duoc chay kiem thu trong Unity Editor.
