INSTALL
1) Copy Assets/Scripts/EraseYouMouse.cs to the same path in your Unity project.
2) In Assets/Scripts/SafeBoxBookFlip.cs, add INSIDE the class:
       public bool IsOpen => isOpen;
   and in ToggleBook(), immediately before 'isOpen = !isOpen;', add:
       if (isOpen) return;
   This prevents the existing Button click from closing the book when releasing the mouse after erasing.
3) On the object assigned to SafeBoxBookFlip.clickSurface, Add Component > Erase You Mouse.
   Drag the object with SafeBoxBookFlip onto its 'Book' field.
4) Select the open-book PNG in Project. In Inspector enable Read/Write, ensure Sprite (2D and UI), Mesh Type Full Rect; Apply.
5) Make sure the clickSurface Button covers the page and Image raycastTarget is enabled.
6) In EraseYouMouse Inspector adjust eraseArea (normalized from bottom-left) so that it covers ONLY the word You, NOT the adjacent status.
7) Adjust cleanPaperSampleOffsetY so that source area contains EMPTY PAPER, otherwise copied text may appear.
8) Play. Open book; hold LMB over You, then drag repeatedly. Leave book via background/Escape.
Notes: This modifies a RAM copy of the texture, not your original PNG. It resets after closing/reopening the book.
