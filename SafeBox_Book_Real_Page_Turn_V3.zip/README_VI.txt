SAFEBOX BOOK COVER FLIP V3 - Unity

Thay 2 file cu:
  Assets/Scripts/SafeBoxBookFlip.cs
  Assets/Editor/SafeBoxBookFlipSetup.cs

Them 1 file moi:
  Assets/Scripts/BookCoverCurl.cs

Khong thay SafeBoxPuzzle.cs, khong thay anh PNG hay scene.

1. Dung Play Mode.
2. Copy thu muc Assets trong ZIP vao goc project, giu nguyen cac file khac.
3. Mo Assets/Scenes/SafeBoxPuzzle.unity.
4. Menu Tools > Safe Box > Install Book Opening Animation.
5. Ctrl+S va Play.

Co che: tam bia duoc chia thanh 24 dai luoi UI, uon cong khi lat tu phai qua trai
quanh gay sach (khong con scale-X hay fade bia); anh sach mo o phia duoi.
Khi mo, khung anh sach mo rong gap doi theo chieu ngang, chieu cao giu nguyen.

Luu y: Do chi co hai anh tinh da raster, do la gia lap 2D page curl, khong phai mo phong
3D vat ly hoan chinh. Neu muon bia mat sau/khep giay cuc that, can asset tach lop.
V3 chua duoc chay thu trong Unity Editor.
