ERASE YOU - FULL FIX (Unity 6)

Copy ONLY these two .cs files into the existing P1/Assets/Scripts/ folder.
Do NOT copy nested Assets/Assets. Replace old SafeBoxBookFlip.cs and EraseYouMouse.cs.
Keep SafeBoxPuzzle.cs and the scene unchanged.

If Assets/Editor/SafeBoxBookFlipSetup.cs still includes references to flipDuration or openedSizeMultiplier,
remove ONLY those obsolete assignment lines (the project previously needed this change).
Do not rerun the old Book Opening Animation installer.

UNITY INSPECTOR:
1. In SafeBoxPuzzle scene, use the UI object that covers/clicks the book (clickSurface).
2. Add EraseYouMouse to that SAME object; assign Book to object with SafeBoxBookFlip.
3. Ensure Image on clickSurface has Raycast Target ON and sits on top of the book image.
4. In SafeBoxBookFlip assign bookImage, closedBookSprite, openedBookSprite, clickSurface.
5. Set the opened-book PNG Texture Type: Sprite (2D and UI), Read/Write Enabled: ON, Mesh Type: Full Rect; Apply.
6. Test opening, holding left mouse and dragging across 'You'. Adjust eraseArea normalized UV in Inspector.
7. eraseArea is (x,y,width,height), bottom-left = (0,0). The default is an ESTIMATE and may not align exactly.
8. cleanPaperSampleOffsetY must point to a text-free patch; otherwise other print/patterns may smear into erased area.

When user closes book view then reopens it, the erasure runtime image may persist until EraseYouMouse
is disabled; the original PNG on disk is never altered. No Unity runtime test was performed here.
