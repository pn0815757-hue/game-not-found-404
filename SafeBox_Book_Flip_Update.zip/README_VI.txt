SAFEBOX BOOK FLIP - HUONG DAN

1. Giai nen ZIP vao THU MUC GOC du an Unity (P1), de tao:
   Assets/Scripts/SafeBoxBookFlip.cs
   Assets/Editor/SafeBoxBookFlipSetup.cs
2. Mo Unity, doi script compile, mo Assets/Scenes/SafeBoxPuzzle.unity.
3. Menu Tools > Safe Box > Install Book Opening Animation.
4. Play: nhap 0904, click cuon so ben trong hop -> xem SO DONG.
   Click vao so dong -> hieu ung lat -> SO MO.
   Click tiep -> hieu ung dong so; click nen den / Escape de tro lai hop.

SU DUNG HAI PNG CO SAN TRONG REPOSITORY, KHONG CAN COPY PNG:
Assets/Sprites/SafeBox/Sổ tay da cũ phong cách pixel art.png (so dong)
Assets/Sprites/SafeBox/Sổ phòng pixel art cổ điển.png (so mo)

Anh hien thi cung RectTransform 672x820, preserveAspect de khong meo anh,
trung tam, co the co vien trong neu hai anh khac ty le.

CHU Y: Neu 2 anh bi dao trang thai, doi Closed/Open trong component
SafeBoxBookFlip o BookViewPanel sau khi cai dat.

Khong can sua code cu; khong ghi de scene goc. Menu setup se sua scene
qua Unity Editor va luu thay doi de git commit sau.
